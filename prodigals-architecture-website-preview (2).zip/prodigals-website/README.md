# Prodigals Architecture — website preview

Open `index.html` in a browser, or serve this folder with `python -m http.server 8000` and visit http://localhost:8000.

## Included
Responsive editorial homepage with exact uploaded logo, historical Dizenyograph photo archive, project detail modal, category filtering, services, process, mission/vision, faith philosophy, and a consultation form that opens a draft email. All seven uploaded photos are included.

## Before a public launch
This is a **functional front-end prototype**, not a production-ready full-stack site. The inquiry form does not send to a server; no company recipient address was provided. Implement a secure backend, email notifications, spam prevention, privacy notice and consent storage, and optional document uploads. Add authenticated CMS, project editing, analytics, SEO sitemap, and proper service-specific pages. Confirm licensed professional credentials, construction licensing, historical project roles and permissions, client naming permission, company contact details, and registration. Do not publish until approved. The archived photo watermarks have deliberately not been altered.

## Suggested production stack
Next.js + TypeScript + Tailwind + a headless CMS (e.g. Sanity), secure storage and server-side inquiry endpoint. The prototype is framework-independent so the design can be migrated.
